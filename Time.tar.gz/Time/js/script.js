var currentDate = new Date();

setInterval(
    function(){
        if (currentDate.getSeconds() != (new Date()).setSeconds()){
            var currentdate = new Date();
            graphFunction(Math.floor(currentdate.getHours() / 10) ,'#char01');
            graphFunction(currentdate.getHours() % 10,'#char02');
            graphFunction(Math.floor(currentdate.getUTCMinutes() / 10) ,'#char03');
            graphFunction(currentdate.getUTCMinutes() % 10,'#char04');
            currentDate = new Date();
        }
});

function graphFunction(index , idModify) {
    switch(index){
        case 0:
            $(idModify+' div:nth-child(1)').removeClass();
            $(idModify+' div:nth-child(2)').removeClass();
            $(idModify+' div:nth-child(1)').addClass('child01');
            $(idModify+' div:nth-child(2)').addClass('child02');
            break;
        case 1:
            $(idModify+' div:nth-child(1)').removeClass();
            $(idModify+' div:nth-child(2)').removeClass();
            $(idModify+' div:nth-child(1)').addClass('child11');
            $(idModify+' div:nth-child(2)').addClass('child12');
            break;
        case 2:
            $(idModify+' div:nth-child(1)').removeClass();
            $(idModify+' div:nth-child(2)').removeClass();
            $(idModify+' div:nth-child(1)').addClass('child21');
            $(idModify+' div:nth-child(2)').addClass('child22');
            break;
        case 3:
            $(idModify+' div:nth-child(1)').removeClass();
            $(idModify+' div:nth-child(2)').removeClass();
            $(idModify+' div:nth-child(1)').addClass('child31');
            $(idModify+' div:nth-child(2)').addClass('child32');
            break;
        case 4:
            $(idModify+' div:nth-child(1)').removeClass();
            $(idModify+' div:nth-child(2)').removeClass();
            $(idModify+' div:nth-child(1)').addClass('child41');
            $(idModify+' div:nth-child(2)').addClass('child42');
            break;
        case 5:
            $(idModify+' div:nth-child(1)').removeClass();
            $(idModify+' div:nth-child(2)').removeClass();
            $(idModify+' div:nth-child(1)').addClass('child51');
            $(idModify+' div:nth-child(2)').addClass('child52');
            break;
        case 6:
            $(idModify+' div:nth-child(1)').removeClass();
            $(idModify+' div:nth-child(2)').removeClass();
            $(idModify+' div:nth-child(1)').addClass('child61');
            $(idModify+' div:nth-child(2)').addClass('child62');
            break;        
        case 7:
            $(idModify+' div:nth-child(1)').removeClass();
            $(idModify+' div:nth-child(2)').removeClass();
            $(idModify+' div:nth-child(1)').addClass('child71');
            $(idModify+' div:nth-child(2)').addClass('child72');
            break;        
        case 8:
            $(idModify+' div:nth-child(1)').removeClass();
            $(idModify+' div:nth-child(2)').removeClass();
            $(idModify+' div:nth-child(1)').addClass('child81');
            $(idModify+' div:nth-child(2)').addClass('child82');
            break;        
        case 9:
            $(idModify+' div:nth-child(1)').removeClass();
            $(idModify+' div:nth-child(2)').removeClass();
            $(idModify+' div:nth-child(1)').addClass('child91');
            $(idModify+' div:nth-child(2)').addClass('child92');
            break;
    }
}